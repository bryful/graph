﻿//外部コマンドを呼ぶサンプル
Console.WriteLine("Hello World!");
MessageBox.Show("Hello World!");